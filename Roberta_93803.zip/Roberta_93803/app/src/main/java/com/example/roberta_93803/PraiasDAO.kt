package com.example.roberta_93803



class PraiasDAO {

    fun adiciona(praia: Praia) {
        Companion.praias.add(praia)
    }

    fun buscaTodos(): List<Praia> {
        return Companion.praias.toList()
    }

    // fun buscaPraiaPorNome(nome: String): Praia? {
    //   for (praia in listaDePraias) {
    ;//  if (praia.nomePraia == nome) {
    //    return praia
//        }
    // return null
    //}



    companion object {
        private val praias = mutableListOf<Praia>()
    }
}