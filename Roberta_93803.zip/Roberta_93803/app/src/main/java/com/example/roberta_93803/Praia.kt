package com.example.roberta_93803

data class Praia(
    val nomePraia: String,
    val cidade: String,
    val estado: String,
)
