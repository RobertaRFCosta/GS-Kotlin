package com.example.roberta_93803.ui.theme

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.roberta_93803.Praia
import com.example.roberta_93803.R


class ListaProdutosAdapter(
    private val context: Context,
    private val praias: List<Praia>
) : RecyclerView.Adapter<ListaProdutosAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        fun vincula(praia: Praia) {
            val nomePraia = itemView.findViewById<TextView>(R.id.nomepraia)
            nomePraia.text = praia.nomePraia

            val cidade = itemView.findViewById<TextView>(R.id.cidade)
            cidade.text = praia.cidade

            val estado = itemView.findViewById<TextView>(R.id.estado)
            estado.text = praia.estado
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ListaProdutosAdapter.ViewHolder {
        val inflater = LayoutInflater.from(context)
        val view = inflater.inflate(R.layout.produto_item, parent, false)
        return ListaProdutosAdapter.ViewHolder(view)
    }

    override fun getItemCount(): Int = praias.size

    override fun onBindViewHolder(holder: ListaProdutosAdapter.ViewHolder, position: Int) {
        val praia = praias[position]
        holder.vincula(praia)
    }
}
