package com.example.roberta_93803

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class FormularioProdutoActivity : AppCompatActivity(R.layout.activity_formulario_produto) {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val botaoIncluir = findViewById<Button>(R.id.botao_incluir)

        botaoIncluir.setOnClickListener {
            val campoNome = findViewById<EditText>(R.id.nomepraia)
            val campoCidade = findViewById<EditText>(R.id.cidade)
            val campoEstado = findViewById<EditText>(R.id.estado)

            val nome = campoNome.text.toString()
            val cidade = campoCidade.text.toString()
            val estado = campoEstado.text.toString()



            val praiaNovo = Praia(
                nomePraia = nome,
                cidade = cidade,
                estado = estado
            )

            Log.i("FormularioProduto", "onCreate: $praiaNovo")
            val dao = PraiasDAO()
            dao.adiciona(praiaNovo)
            Log.i("FormularioProduto", "onCreate: ${dao.buscaTodos()}")

            finish()
        }
    }
}